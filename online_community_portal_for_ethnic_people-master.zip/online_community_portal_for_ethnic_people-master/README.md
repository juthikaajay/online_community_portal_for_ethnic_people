# online_community_portal_for_ethnic_people

this repository developed by html5,css3,php,ajax,jquery,javascript
